public class For1
{ public static void main (String args[])
  { int i ;
    for (i=1 ; i<=5 ; i++)
     { System.out.print ("bonjour ") ;
       System.out.println (i + " fois") ;
     }
  }
}


