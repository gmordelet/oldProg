public class For3
{ public static void main (String args[])
  { int i, j ;
    for (i=1 , j=3 ; i<=5 ; i++, j+=i)
     { System.out.println ("i = " + i + "  j = " + j) ;
     }
  }
}


