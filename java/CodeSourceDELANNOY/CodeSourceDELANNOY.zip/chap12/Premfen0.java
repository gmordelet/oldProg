import javax.swing.* ;
public class Premfen0
{ public static void main (String args[])
  { JFrame fen = new JFrame() ;
    fen.setSize (300, 150) ;
    fen.setTitle ("Ma premiere fenetre") ;
    fen.setVisible (true) ;
  }
}

