public class ErrAffEl
{ public static void main (String args[])
  { byte b=10 ;
    int n = 10000 ;
    b+=n ;
    System.out.println ("b = " + b) ;
  }
}

