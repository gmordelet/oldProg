public class PremProg                                            //genes\PremProg.java
{ public static void main (String[] args)
  { System.out.println ("Mon premier programme Java") ;
  }
}
