public class Exemple
{ public static void main (String[] args)
  { int n ;
    double x ;
    n = 5 ;
    x = 2*n + 1.5 ;
    System.out.println ("n = " + n) ;
    System.out.println ("x = " + x) ;
    double y ;
    y = n * x + 12 ;
    System.out.println ("y = " + y) ;
  }
}



