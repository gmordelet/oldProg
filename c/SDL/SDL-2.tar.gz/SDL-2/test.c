#include <stdio.h>
#include "SDL.h"

/* Variable permettant de quitter la boucle de jeu */
unsigned char letsexit = 0;
/* V�locit� du sprite */
Uint16 xvel = 0, yvel = 0;
/* Position du sprite */
SDL_Rect spritepos;

/* Gestion des �v�nements d'entr�e */
void process_events()
{
     SDL_Event event;
     /* Un �v�nement attend d'�tre trait�? */
     while (SDL_PollEvent(&event))
     {
	  /* Si oui, quel type? */
	  switch (event.type)
	  {
          /* Appui sur une touche */
	  case SDL_KEYDOWN:
	       printf("Touche %d enfonc�e (caract�re produit: %c)\n",
		      event.key.keysym.sym, 
		      event.key.keysym.unicode);
	       switch (event.key.keysym.sym)
	       {
	       case SDLK_ESCAPE:
		    letsexit = 1;
		    break;
	       case SDLK_LEFT:
		    xvel = -1;
		    break;
	       case SDLK_RIGHT:
		    xvel = 1;
		    break;
	       case SDLK_UP:
		    yvel = -1;
		    break;
	       case SDLK_DOWN:
		    yvel = 1;
		    break;
	       default:
		    break;
	       }
	       break;
          /* Rel�chement d'une touche */
	  case SDL_KEYUP:
	       printf("Touche %d rel�ch�e\n", event.key.keysym.sym);
	       switch (event.key.keysym.sym)
	       {
	       case SDLK_LEFT:
	       case SDLK_RIGHT:
		    xvel =0;
		    break;
	       case SDLK_UP:
	       case SDLK_DOWN:
		    yvel = 0;
		    break;
	       default:
		    break;
	       }
	       break;
          /* D�placement souris */
	  case SDL_MOUSEMOTION:
	       spritepos.x += event.motion.xrel;
	       spritepos.y += event.motion.yrel;
	       printf("Position souris: (%d, %d)\n", event.motion.x,
		      event.motion.y);
	       break;
          /* Enfoncement bouton souris */
	  case SDL_MOUSEBUTTONDOWN:
	       printf("Click bouton souris %d\n", event.button.button);
	       break;
          /* Rel�chement bouton souris */
	  case SDL_MOUSEBUTTONUP:
	       printf("Rel�chement bouton souris %d\n", event.button.button);
	       break;
          /* D�placement axe joystick */
	  case SDL_JOYAXISMOTION:
	       printf("Axe %d du joystick %d positionn� � %d\n",
		      event.jaxis.axis, event.jaxis.which, event.jaxis.value);
	       /* Les axes pairs sont verticaux, les impairs horizontaux.
		  Les valeurs de jaxis.value �tant tr�s grandes, on compense
		  en faisant un d�calage � droite (division par 2^13) */
	       if (event.jaxis.axis % 2)
		    yvel = event.jaxis.value >> 13;
	       else
		    xvel = event.jaxis.value >> 13;
	       break;
          /* D�placement chapeau joystick */
	  case SDL_JOYHATMOTION:
	       printf("Chapeau %d du joystick %d en position ",
		      event.jhat.hat, event.jhat.which);
	       switch (event.jhat.value)
	       {
	       case SDL_HAT_CENTERED:
		    xvel = 0; yvel = 0;
		    printf("centr�e\n");
		    break;
	       case SDL_HAT_UP:
		    xvel = 0; yvel = -1;
		    printf("haute\n");
		    break;
	       case SDL_HAT_RIGHT:
		    xvel = 1; yvel = 0;
		    printf("droite\n");
		    break;
	       case SDL_HAT_DOWN:
		    xvel = 0; yvel = 1;
		    printf("basse\n");
		    break;
	       case SDL_HAT_LEFT:
		    xvel = -1; yvel = 0;
		    printf("gauche\n");
		    break;
	       case SDL_HAT_RIGHTUP:
		    xvel = 1; yvel = -1;
		    printf("haute/droite\n");
		    break;
	       case SDL_HAT_RIGHTDOWN:
		    xvel = 1; yvel = 1;
		    printf("basse/droite\n");
		    break;
	       case SDL_HAT_LEFTUP:
		    xvel = -1; yvel = -1;
		    printf("haute/gauche\n");
		    break;
	       case SDL_HAT_LEFTDOWN:
		    xvel = -1; yvel = 1;
		    printf("basse/gauche\n");
		    break;
	       }
	       break;
          /* D�placement trackball joystick */
	  case SDL_JOYBALLMOTION:
	       spritepos.x += event.jball.xrel;
	       spritepos.y += event.jball.yrel;
	       printf("Trackball %d du joystick %d a boug� de (%d, %d)\n",
		      event.jball.ball, event.jball.which, 
		      event.jball.xrel, event.jball.yrel);
	       break;
          /* Appui bouton joystick */
	  case SDL_JOYBUTTONDOWN:
	       printf("Bouton %d du joystick %d enfonc�\n",
		      event.jbutton.button, event.jbutton.which);
	       break;
          /* Rel�chement bouton joystick */
	  case SDL_JOYBUTTONUP:
	       printf("Bouton %d du joystick %d rel�ch�\n",
		      event.jbutton.button, event.jbutton.which);
	       break;
	  default:
	       break;
	  }
     }    
}

#define SDL_VIDEO_FLAGS (SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_ANYFORMAT)

int main(int argc, char * argv[])
{
     SDL_Surface * screen;
     SDL_Surface * sprite, * tmp;
     int nbjoysticks;
     int i;

     if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) == -1)
     {
	  fprintf(stderr, "Erreur lors de l'initialisation de SDL: %s\n",
		  SDL_GetError());
	  return 1;
     }

     screen = SDL_SetVideoMode(640, 480, 24, SDL_VIDEO_FLAGS);
     printf("Mode vid�o: %dx%dx%d\n", screen->w, screen->h, 
	    screen->format->BitsPerPixel);

     /* Activation du support UNICODE */
     SDL_EnableUNICODE(1);

     nbjoysticks = SDL_NumJoysticks();
     printf("Nombres de joysticks attach�s: %d\n\n", nbjoysticks);

     for (i = 0; i < nbjoysticks; i++)
     {
	  SDL_Joystick * joy = SDL_JoystickOpen(i);
	  printf("Joystick %d: %s\n", i, SDL_JoystickName(i));
	  printf("Axes: %d\n", SDL_JoystickNumAxes(joy));
	  printf("Boutons: %d\n", SDL_JoystickNumButtons(joy));
	  printf("Trackballs: %d\n", SDL_JoystickNumBalls(joy));
	  printf("Chapeaux: %d\n\n", SDL_JoystickNumHats(joy));
     }

     /* Chargement du sprite */
     tmp = SDL_LoadBMP("image.bmp");
     sprite = SDL_DisplayFormat(tmp);
     SDL_FreeSurface(tmp);
     SDL_SetColorKey(sprite, SDL_SRCCOLORKEY, SDL_MapRGB(sprite->format, 0xff, 0x00, 0xff));

     /* Position initiale du sprite */
     spritepos.x = (screen->w - sprite->w) / 2;
     spritepos.y = (screen->h - sprite->h) / 2;
     spritepos.w = 0;
     spritepos.h = 0;

     /* Boucle de jeu */
     while (!letsexit)
     {
	  /* Mise � jour de l'�tat du jeu � partir des
	     �v�nements */
	  process_events();

	  /* Mise � jour de la position du sprite � partir
	     de sa v�locit� */
	  spritepos.x += xvel;
	  spritepos.y += yvel;
	  /* Test de d�bordement d'�cran */
	  if (spritepos.x < 0) spritepos.x = 0;
	  if (spritepos.x > screen->w - sprite->w) spritepos.x = screen->w - sprite->w;
	  if (spritepos.y < 0) spritepos.y = 0;
	  if (spritepos.y > screen->h - sprite->h) spritepos.y = screen->h - sprite->h;

	  /* Mise � jour de l'�cran */
	  /* Remplissage de l'�cran en noir */
	  SDL_FillRect(screen, NULL, 0);
	  /* Affichage du sprite puis mise � jour du
	     buffer d'affichage */
	  SDL_BlitSurface(sprite, NULL, screen, &spritepos);
	  SDL_Flip(screen);
     }

     SDL_Quit();
     return 0;
}
